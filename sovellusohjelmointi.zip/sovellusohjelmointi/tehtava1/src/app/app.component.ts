import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'tehtava1';

  //Alustetaan muuttujat
  pituus : number;
  metreissa : number;
  paino : number;
  tulos2 : string;
  vari : string;
  //Valitti rivillä 26 virhettä joten tämä "tulos : any" on nopea virheenkorjaus... (toFixed() aiheutti virheen?)
  tulos : any;

  //Funktio
  laske = () : void => {

    //Muutetaan pituus metreiksi
    this.metreissa = this.pituus / 100;
    //Lasketaan painoindeksi ja pyöristetään kahden(2) desimaalin tarkkuuteen
    this.tulos = (this.paino / this.metreissa / this.metreissa).toFixed(2);
    //Tarkastetaan painoindeksin kuvausteksti ja Alert-komponentin väri lukuisilla if-lausekkeilla
    if (this.tulos < 15)  {
      this.tulos2 = "Sairaalloinen alipaino";
      this.vari = "alert alert-danger";
    }if (this.tulos >= 15 && this.tulos < 17)  {
      this.tulos2 = "Merkittävä alipaino";
      this.vari = "alert alert-danger";
    }if (this.tulos >= 17 && this.tulos < 18.5)  {
      this.tulos2 = "Normaalia alhaisempi paino";
      this.vari = "alert alert-warning";
    }if (this.tulos >= 18.5 && this.tulos < 25)  {
      this.tulos2 = "Normaali paino";
      this.vari = "alert alert-success";
    }if (this.tulos >= 25 && this.tulos < 30)  {
      this.tulos2 = "Lievä ylipaino";
      this.vari = "alert alert-warning";
    }if (this.tulos >= 30 && this.tulos < 35)  {
      this.tulos2 = "Merkittävä ylipaino";
      this.vari = "alert alert-danger";
    }if (this.tulos >= 35 && this.tulos < 40)  {
      this.tulos2 = "Vaikea ylipaino";
      this.vari = "alert alert-danger";
    }if (this.tulos > 40)  {
      this.tulos2 = "Sairaalloinen ylipaino";
      this.vari = "alert alert-danger";
    } 
    //Tulostetaan vastaus käyttäjälle
    this.tulos = `Painoindeksi on: ${this.tulos}`;
  }
    
}
