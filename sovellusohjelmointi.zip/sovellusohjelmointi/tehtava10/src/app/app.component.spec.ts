import { AppComponent } from './app.component';

describe("perustoiminnallisuus", () => {

    const app = new AppComponent();

    it("kaynnistyy", () => {

        //Onko appi olemassa
        expect(app).toBeTruthy();
    });

    it("Jos syöttötiedot ovat väärät", () => {

        //ei syöttötietoja
        app.paino = null;
        app.pituus = null;
        app.laske();
        expect(app.tulos).toContain("virhe");
        //Ei numeraalisia arvoja
        app.paino = NaN;
        app.pituus = NaN;
        app.laske();
        expect(app.tulos).toContain("virhe");
        //Alle 30kg ja alle 100cm
        app.paino = 29;
        app.pituus = 99;
        app.laske();
        expect(app.tulos).toContain("virhe");
        //Yli 230kg ja yli 230cm
        app.paino = 231;
        app.pituus = 231;
        app.laske();
        expect(app.tulos).toContain("virhe");

    });

    it("Näytetään tulos sopivilla syötteillä", () => {

        app.paino = 230;
        app.pituus = 178;
        app.laske();
        
        //Tulokset sisältävät:
        expect(app.tulos).toContain("Painoindeksi");
        expect(app.tulos2).toContain("paino");

    });



});