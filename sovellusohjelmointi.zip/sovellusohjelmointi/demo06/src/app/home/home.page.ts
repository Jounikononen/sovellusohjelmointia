import { LomakePage } from './../lomake/lomake.page';
import { Component } from '@angular/core';
import { AlertController, ModalController } from '@ionic/angular';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

viesti : string = "";

  constructor(private dialogiCtrl : AlertController, private modalCtrl : ModalController) {}

//Yksinkertainen dialogi-ikkuna
avaa = async () : Promise<any> => {
  const ikkuna = await this.dialogiCtrl.create({
                                          header  : "info",
                                          message : "Tässä asia tiedoksesi!",
                                          buttons : ["Ok"] 
                                        });
  await ikkuna.present();
}
vahvista = async () : Promise<any> => {
  const ikkuna = await this.dialogiCtrl.create({
                                          header  : "Vahvista",
                                          message : "Oletko aivan varma?",
                                          buttons : [
                                                      {
                                                        text : "Kyllä",
                                                        handler : () => {
                                                          this.viesti = "Hyvä, asia on siis varma!";
                                                        }
                                                      },
                                                      {
                                                        text : "Ei",
                                                        role : "cancel",
                                                        cssClass : "secondary",
                                                        handler : () => {
                                                          this.viesti = "Peruutettu!";
                                                        }
                                                      },
                                                    ]
                                        });
  await ikkuna.present();
}
kysely = async () : Promise<any> => {
  const ikkuna = await this.dialogiCtrl.create({
                                          header  : "Kysely",
                                          message : "Anna tietosi",
                                          inputs : [
                                                    {
                                                      name : "nimi",
                                                      type : "text",
                                                      placeholder : "Kirjoita nimesi..."
                                                    }
                                                  ],
                                          buttons : [
                                                      {
                                                        text : "Ok",
                                                        handler : (data : any) => {
                                                          this.viesti = `Heippa, ${data.nimi}!`;
                                                        }
                                                      },
                                                      {
                                                        text : "Peruuta",
                                                        role : "cancel",
                                                        cssClass : "secondary",
                                                        handler : () => {
                                                          this.viesti = "Heippa, tuntematon!";
                                                        }
                                                      },
                                                    ]
                                        });
  await ikkuna.present();
}

kyselylomake = async () : Promise<any> => {

let lomakeoletukset = {
                      etunimi : "Jaska",
                      sukunimi : "Jokunen",
                      email : null,
                      puhelin : null

                    }

const ikkuna = await this.modalCtrl.create({
                                             component : LomakePage,
                                             componentProps : { lomake : lomakeoletukset}

                                          });

await ikkuna.present();

ikkuna.onDidDismiss().then((lomake) => {

if (lomake) {

  this.viesti = `Uusi jäsen lisätty tiedoin: ${lomake.data.etunimi} 
  ${lomake.data.sukunimi} 
  ${lomake.data.email} 
  ${lomake.data.puhelin}`;

} else {
  this.viesti = "";
}

  

});

}

}
