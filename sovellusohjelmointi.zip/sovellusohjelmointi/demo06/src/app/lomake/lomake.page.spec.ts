import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LomakePage } from './lomake.page';

describe('LomakePage', () => {
  let component: LomakePage;
  let fixture: ComponentFixture<LomakePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LomakePage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LomakePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
