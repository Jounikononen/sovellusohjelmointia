import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-lomake',
  templateUrl: './lomake.page.html',
  styleUrls: ['./lomake.page.scss'],
})
export class LomakePage implements OnInit {

lomake = {
  etunimi : "",
  sukunimi : "",
  email : "",
  puhelin : ""
}

  constructor(private modalCtrl : ModalController) { }

  ngOnInit() {
  }

peruuta = () => {

  this.modalCtrl.dismiss();

}

tallenna = () => {

  this.modalCtrl.dismiss(this.lomake);

}

}
