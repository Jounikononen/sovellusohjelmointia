import { Component, OnInit } from '@angular/core';
import { TehtavalistaService } from '../tehtavalista.service';

@Component({
  selector: 'app-lista',
  templateUrl: './lista.component.html',
  styleUrls: ['./lista.component.css']
})
export class ListaComponent implements OnInit {

 



  constructor(private tehtavalista : TehtavalistaService) { }

  ngOnInit() {
  }

}
