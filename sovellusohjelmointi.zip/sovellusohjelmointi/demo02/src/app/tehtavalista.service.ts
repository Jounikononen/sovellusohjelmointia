import { Injectable } from '@angular/core';
import{ Tehtava } from './Tehtava';

@Injectable({
  providedIn: 'root'
})
export class TehtavalistaService {

  tehtavat : Tehtava[] = [ {
    id: 1,
    nimi : "Siivoa",
    ohje : "Myös maton alta"
  },
  {
    id : 2,
    nimi : "Käy kaupassa",
    ohje : "Muista "
  },
  {
    id : 3,
    nimi : "Ulkoiluta koira",
    ohje : "Muista kakkapussi"
  }
  ];

  constructor() { 



  }
}
