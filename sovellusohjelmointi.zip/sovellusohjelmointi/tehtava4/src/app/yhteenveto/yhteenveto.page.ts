import { DataService } from './../data.service';
import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-yhteenveto',
  templateUrl: './yhteenveto.page.html',
  styleUrls: ['./yhteenveto.page.scss'],
})
export class YhteenvetoPage implements OnInit {

//Laita interfaceen
kokeilu : any;
kokeilu2 : any;
yhteensa : number;
pvm : any;
pituus : number;
mokki : any;
siivous : any;
nimi : string;
puh : number;
sposti : string;
maksu : any;

  constructor(private data : DataService) { }
  testi() {
//Tässä kokonaisuudessaan monimutkainen ratkaisu yhteenvetoon
    this.kokeilu = this.data.datat.length;
    this.kokeilu2 = this.data.tiedot.length;

//Poistetaan tässä aikaisemmat arrayt 
//En saanut toimivaa koodia siihen, 
//että tietojen syöttäminen korvaa aikaisemman arrayn
if(this.kokeilu >= 2) {
    this.data.datat.shift();
} else if (this.kokeilu2 >= 2) {
    this.data.tiedot.shift();
} else {
    //tämä toimii...
    this.yhteensa = this.data.datat.map(t => t.yhteensa);
    this.pvm = this.data.datat.map(t => t.pvm);
    this.pituus = this.data.datat.map(t => t.pituus);
    this.mokki = this.data.datat.map(t => t.mokki);
    this.siivous = this.data.datat.map(t => t.siivous);
    this.nimi = this.data.tiedot.map(t => t.nimi);
    this.puh = this.data.tiedot.map(t => t.puh);
    this.sposti = this.data.tiedot.map(t => t.sposti);
    this.maksu = this.data.tiedot.map(t => t.maksu);
    
    //Mökin nimi yhteenvetoon hinnan perusteella
    if(this.mokki == 80) {
      this.mokki = "Perusmökki";
    } else if (this.mokki == 10) {
      this.mokki = "Erämökki";
    } else if (this.mokki == 150) {
      this.mokki = "Rantamökki";
    } else if (this.mokki == 300) {
      this.mokki = "Huvila";
    }  
    
    //Jos siivouspalvelu niin kyllä
    if(this.siivous == "true") {
      this.siivous = "kyllä";
    } else {this.siivous = "Ei";}
    
    return this.yhteensa;
}
}
  ngOnInit() {
  }

}
