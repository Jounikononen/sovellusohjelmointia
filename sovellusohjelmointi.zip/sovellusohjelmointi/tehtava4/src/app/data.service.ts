import { Injectable } from '@angular/core';


@Injectable({
  providedIn: 'root'
})
export class DataService {

//Luodaan arrayt tiedoille (mökki ja varaaja)
datat : any = [];
tiedot : any = [];

  constructor() { }
}
