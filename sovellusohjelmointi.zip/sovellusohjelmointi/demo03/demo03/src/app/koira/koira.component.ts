import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-koira',
  templateUrl: './koira.component.html',
  styleUrls: ['./koira.component.css']
})
export class KoiraComponent implements OnInit {

kuvaUrl : string= "";
url : string = "https://dog.ceo/api/breeds/image/random";

  constructor(private http : HttpClient) { 

    this.haeTiedot();

  }

  ngOnInit() {
  }

haeTiedot = () : void => {

  this.http.get(this.url).subscribe((data : any) => {

    this.kuvaUrl = data.message;
    

    console.log(data);

  },
  (err : any) => {
    console.log(err);
  });

}

}
