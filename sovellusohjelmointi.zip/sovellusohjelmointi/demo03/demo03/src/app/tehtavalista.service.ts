import { Injectable } from '@angular/core';
import{ Tehtava } from './Tehtava';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class TehtavalistaService {

  tehtavat : Tehtava[] = [];

url : string = "http://localhost:3010/api/tehtavalista";

  constructor(private http : HttpClient) { 

    this.haeTiedot();

  }

    haeTiedot = () : void => {

        this.http.get(this.url).subscribe((data : Tehtava[]) => {

            console.log(data);

            this.tehtavat = data;

        });

    }

    tallennaTiedot = () : void => {

      this.http.put(this.url, this.tehtavat).subscribe((data : any) => {

        console.log(data);

      });

    }
  
}
