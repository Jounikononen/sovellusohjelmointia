import { Component } from '@angular/core';
import { VelkalistaService } from './velkalista.service';
import { SaatavalistaService } from './saatavalista.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'tehtava2';

  constructor(private velkalista : VelkalistaService, private saatavalista : SaatavalistaService) { }
  yhteensa() {
    return this.velkalista.velat.map(t => t.maara).reduce((acc, value) => acc + value,0);
  
   }
  yhteensa2() {
    return this.saatavalista.saatavat.map(t => t.maara).reduce((acc, value) => acc + value,0);
  
   }
}
