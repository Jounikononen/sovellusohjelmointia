import { Component, OnInit } from '@angular/core';
import { SaatavalistaService } from '../saatavalista.service';
import { Saatava } from '../Saatava';
import { Router } from '@angular/router';

@Component({
  selector: 'app-saatavat',
  templateUrl: './saatavat.component.html',
  styleUrls: ['./saatavat.component.css']
})
export class SaatavatComponent implements OnInit {

  id : number = 1;
nimi : string;
maara : number;

  constructor(private saatavalista : SaatavalistaService, private router : Router) { }

  ngOnInit() {
  }


  //Lisätää uusi velallinen
  lisaaSaatava = () : void => {
    //Velat arrayhin
    let uusiSaatava : Saatava = {
                      "nimi" : this.nimi,
                      "maara" : this.maara
  
                    }
    //Lisätään uusi velka
    this.saatavalista.saatavat.push(uusiSaatava);
                    this.nimi = null;this.maara = null;
  
   }
   //Poistetaan velka nappia painamalla
   poistaSaatava = (i) : void => {
    this.saatavalista.saatavat.splice(i, 1);
    
    
   }
  
   //Lasketaan velan määrä yhteen ja näytetään se velkataulukon alapuolella
   yhteensa2() {
    return this.saatavalista.saatavat.map(t => t.maara).reduce((acc, value) => acc + value,0);
  
   }
  


}
