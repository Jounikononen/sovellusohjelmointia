import { Injectable } from '@angular/core';
import { Saatava } from './Saatava';

@Injectable({
  providedIn: 'root'
})
export class SaatavalistaService {

  saatavat : Saatava[] = [];
  length: number;
  

  constructor() { }
}
