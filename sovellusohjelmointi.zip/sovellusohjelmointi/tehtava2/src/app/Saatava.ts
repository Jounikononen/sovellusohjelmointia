export interface Saatava {
    nimi : string;
    maara : number;
  }
  