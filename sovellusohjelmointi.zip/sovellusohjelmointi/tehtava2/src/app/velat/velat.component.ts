import { Component, OnInit } from '@angular/core';
import { VelkalistaService } from '../velkalista.service';
import { Velka } from '../Velka';
import { Router } from '@angular/router';

@Component({
  selector: 'app-velat',
  templateUrl: './velat.component.html',
  styleUrls: ['./velat.component.css']
})
export class VelatComponent implements OnInit {

  //
  id : number = 1;
nimi : string;
maara : number;


  constructor(private velkalista : VelkalistaService, private router : Router) { }

  ngOnInit() {
  }



  //Lisätää uusi velallinen
 lisaaVelka = () : void => {
  //Velat arrayhin
  let uusiVelka : Velka = {
                    "nimi" : this.nimi,
                    "maara" : this.maara

                  }
  //Lisätään uusi velka
  this.velkalista.velat.push(uusiVelka);
                  this.nimi = null;this.maara = null;

 }
 //Poistetaan velka nappia painamalla
 poistaVelka = (i) : void => {
  this.velkalista.velat.splice(i, 1);
  
  
 }

 //Lasketaan velan määrä yhteen ja näytetään se velkataulukon alapuolella
 yhteensa() {
  return this.velkalista.velat.map(t => t.maara).reduce((acc, value) => acc + value,0);

 }

}
