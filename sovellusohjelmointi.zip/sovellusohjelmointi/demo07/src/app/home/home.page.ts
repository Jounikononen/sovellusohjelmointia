import { Device } from '@ionic-native/device/ngx';
import { Component } from '@angular/core';
import { Vibration } from '@ionic-native/vibration/ngx';
import { Camera, CameraOptions } from '@ionic-native/camera/ngx';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

kuva : string = "";
kuvavirhe : string = "";

  constructor(private laitetiedot : Device, private varina : Vibration, private kamera : Camera) {
  
  }

  varinaa = () : void => {

    this.varina.vibrate(2000);

  }

  otaKuva = () : void => {

    let asetukset : CameraOptions = {
        quality : 70,
        destinationType : 0,
        targetWidth : 320,
        targetHeight : 220
    }

    this.kamera.getPicture(asetukset).then((kuvadata) => {

    this.kuvavirhe = "";

      //Jos ei valmista kansiota, näytetään kuva ilman kansiota
      this.kuva = `data:image/jpeg;base64,${kuvadata}`;

      //Jos virhe niin
    }).catch((err) => {

      this.kuvavirhe = "Kuvaus keskeytetty tai se ei onnistunut."

    })

    

  }

}
