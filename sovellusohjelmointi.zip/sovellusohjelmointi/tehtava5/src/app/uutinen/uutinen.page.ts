import { UutisetService } from './../uutiset.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-uutinen',
  templateUrl: './uutinen.page.html',
  styleUrls: ['./uutinen.page.scss'],
})
export class UutinenPage implements OnInit {

  
  uutinen : any;

  constructor(private route : ActivatedRoute, private uutiset : UutisetService) { }

  ngOnInit() {

    

    let indeksi = Number(this.route.snapshot.paramMap.get("indeksi"));

    this.uutinen = this.uutiset.uutinen[indeksi];

  }
  

}
