import { HenkiloModalPage } from './../henkilo-modal/henkilo-modal.page';
import { HenkilorekisteriService } from './../henkilorekisteri.service';
import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';


@Component({
  selector: 'app-home2',
  templateUrl: './home2.page.html',
  styleUrls: ['./home2.page.scss'],
})
export class Home2Page implements OnInit {

  constructor(private henkilorekisteri : HenkilorekisteriService,
              private modalController : ModalController) { }

  ngOnInit() {
  }

  naytaTiedot = async (henkilo : any) => {

    const modal = await this.modalController.create({
                                                      component : HenkiloModalPage,
                                                      componentProps : { "henkilo" : henkilo }

                                                    });

modal.present();

  

  }

}
