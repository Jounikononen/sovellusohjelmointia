import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HenkiloModalPage } from './henkilo-modal.page';

describe('HenkiloModalPage', () => {
  let component: HenkiloModalPage;
  let fixture: ComponentFixture<HenkiloModalPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HenkiloModalPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HenkiloModalPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
