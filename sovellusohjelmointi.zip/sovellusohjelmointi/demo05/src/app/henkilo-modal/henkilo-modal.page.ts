import { ModalController } from '@ionic/angular';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-henkilo-modal',
  templateUrl: './henkilo-modal.page.html',
  styleUrls: ['./henkilo-modal.page.scss'],
})
export class HenkiloModalPage implements OnInit {

  constructor(private ModalController : ModalController) { }

  ngOnInit() {
  }

  sulje = () : void => {

    this.ModalController.dismiss();

  }

}
