import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)},
  { path: 'henkilo/:indeksi', loadChildren: './henkilo/henkilo.module#HenkiloPageModule' },
  { path: 'home2', loadChildren: './home2/home2.module#Home2PageModule' },
  { path: 'henkilo-modal', loadChildren: './henkilo-modal/henkilo-modal.module#HenkiloModalPageModule' },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
